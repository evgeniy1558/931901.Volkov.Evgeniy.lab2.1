﻿using System;
using LAB_1.Models;
using Microsoft.AspNetCore.Mvc;
namespace LAB_1.Controllers
{
    //логика обработки запросов
    public class CalcServiceController : Controller
    {
        private readonly Random _random = new Random();
        private readonly int x;
        private readonly int y;
        private readonly string add;
        private readonly string sub;
        private readonly string mult;
        private readonly string div;

        public CalcServiceController()
        {
            x = _random.Next() % 10;
            y = _random.Next() % 10;
            add = $"{x} + {y} = {x + y}"; //get запросы
            sub = $"{x} - {y} = {x - y}";
            mult = $"{x} * {y} = {x * y}";
            if (y == 0) div = "Error";
            else div = $"{x} /  {y} = {x / y}";
        }

        public IActionResult Index() //IActionResult 
        {
            return View(); //обращение к представлению 
        }

        //4 модели передачи данных в представления
        public IActionResult PassUsingModel()
        {
            var model = new CalcModel(x, y, add, sub, mult, div);
            return View(model);
        }

        public IActionResult PassUsingViewData() //ключ - значение 
        {
            ViewData["X"] = x;
            ViewData["Y"] = y;
            ViewData["Add"] = add;
            ViewData["Sub"] = sub;
            ViewData["Mult"] = mult;
            ViewData["Div"] = div;
            return View();
        }
        public IActionResult PassUsingViewBag() //передача различных свойств, похож на viewData
        {
            ViewBag.X = x;
            ViewBag.Y = y;
            ViewBag.Sum = add;
            ViewBag.Dif = sub;
            ViewBag.Mult = mult;
            ViewBag.Div = div;
            return View();
        }

        public IActionResult AccessServiceDirectly()
        {
            var model = new CalcModel(x, y, add, sub, mult, div);
            return View(model);
        }
    }
}