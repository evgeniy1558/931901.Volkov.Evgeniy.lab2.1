﻿using System;
using LAB_1.Models;
namespace LAB_1.Services
{
    public class CalcService
    {
        private readonly Random _random = new();

        public CalcModel GetCalcModel()
        {
            var x = _random.Next() % 10;
            var y = _random.Next() % 10;
            return new CalcModel(
                x, y,
                add: $"{x} + {y} = {x + y}",
                sub: $"{x} - {y} = {x - y}",
                mult: $"{x} * {y} = {x * y}",
                div: y != 0 ? $"{x} /  {y} = {x / y}" : "Zero"
            );
        }
    }
}