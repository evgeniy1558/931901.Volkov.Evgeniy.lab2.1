﻿using LAB_1.Models;
using LAB_1.Services;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LAB_1
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services) //регистрирует сервисы , которые выполняются приложением
        {                                                                                           //IServiceCollection  который и представляет коллекцию сервисов в приложении
            services.AddMvc(); //добавляем сервисы mvc
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseStaticFiles();
            app.UseRouting(); //компонент для встраивания маршрутизации 

            app.UseEndpoints(endpoints =>
            {
                    endpoints.MapControllerRoute(
                        name: "default",
                        pattern: "{controller=CalcService}/{action=Index}"
                        );
            });
        }
    }
}
